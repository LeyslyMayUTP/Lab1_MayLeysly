const express = require('express');
const app = express();

const bcryptjs = require('bcryptjs');

app.use(express.urlencoded({extended:false}));
app.use(express.json());

app.post('/login', async (req, res) => {

    //datos que vamos a cargar en postman
    const user = req.body.user;
    const password = req.body.password;

    //comprobamos que sean los datos correctos 
    if(user == 'admin' && password == '50000'){
        let passwordHash = await bcryptjs.hash(password, 8);
        res.json({
            message: 'Autentificacion correcta en el sistema',
            passwordHash: passwordHash
        });
    }else{
        res.json({
            message: 'Intentelo de nuevo'
    })
}
});

app.get('/compare', (req, res)=>{
    let hashSaved = '$2a$08$hau/5ZnkbVqUfoQSX.1E..O7Ym0RGhaBgiTc4zoFjH36xt1SBQVoW';
    let compare = bcryptjs.compareSync('50004', hashSaved);
    if(compare){
        res.json('Ok');
    }else {
        res.json('no son lo mismo');
    }
});

app.listen(3000, ()=> {
    console.log('Servidor Corriendo');
});